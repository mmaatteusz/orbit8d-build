# Informacje o komponentach zewnętrznych

Orbit 8D korzysta z pakietów open source wymienionych w `pubspec.yaml`.

Najważniejszym komponentem jest `ffmpeg_kit_flutter_new_audio`, udostępniany na
warunkach LGPL 3.0 i zawierający FFmpeg oraz biblioteki audio. Przed dystrybucją
w Google Play lub App Store trzeba dołączyć właściwe teksty licencji, informacje
o wersjach i spełnić obowiązki wynikające z LGPL dla ostatecznego sposobu
linkowania aplikacji.

Kod aplikacji nie używa wariantu FFmpeg zawierającego komponenty GPL do wideo.
Pozostałe zależności korzystają m.in. z licencji MIT, BSD-3-Clause i Apache-2.0.
Pełną listę wersji blokuje wygenerowany przez Flutter plik `pubspec.lock`.
