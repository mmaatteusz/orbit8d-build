import 'dart:io';

void main() {
  final gradleFile = File('android/app/build.gradle.kts');
  final manifestFile = File('android/app/src/main/AndroidManifest.xml');
  if (!gradleFile.existsSync() || !manifestFile.existsSync()) {
    stderr.writeln('Najpierw uruchom flutter create dla platformy Android.');
    exitCode = 1;
    return;
  }

  var gradle = gradleFile.readAsStringSync();
  if (!gradle.contains('orbit8dUploadKeystore')) {
    gradle = '''import java.util.Properties

val orbit8dKeystoreProperties = Properties()
val orbit8dKeystoreFile = rootProject.file("key.properties")
if (orbit8dKeystoreFile.exists()) {
    orbit8dKeystoreFile.inputStream().use { orbit8dKeystoreProperties.load(it) }
}
val orbit8dUploadKeystore = orbit8dKeystoreFile.exists()

$gradle''';

    gradle = gradle.replaceFirst(
      'android {',
      '''android {
    signingConfigs {
        create("release") {
            if (orbit8dUploadKeystore) {
                keyAlias = orbit8dKeystoreProperties["keyAlias"] as String
                keyPassword = orbit8dKeystoreProperties["keyPassword"] as String
                storeFile = file(orbit8dKeystoreProperties["storeFile"] as String)
                storePassword = orbit8dKeystoreProperties["storePassword"] as String
            }
        }
    }''',
    );

    gradle = gradle.replaceFirst(
      '    buildTypes {',
      '''    flavorDimensions += "edition"
    productFlavors {
        create("play") {
            dimension = "edition"
            applicationIdSuffix = ".play"
            resValue("string", "app_name", "Orbit8D")
        }
        create("private") {
            dimension = "edition"
            applicationIdSuffix = ".private"
            resValue("string", "app_name", "Orbit8D Private")
        }
    }

    buildTypes {''',
    );

    gradle = gradle.replaceFirst(
      'signingConfig = signingConfigs.getByName("debug")',
      '''signingConfig = if (orbit8dUploadKeystore) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }''',
    );
    gradleFile.writeAsStringSync(gradle);
  }

  var manifest = manifestFile.readAsStringSync();
  manifest = manifest.replaceAll(
    'android:label="orbit8d"',
    'android:label="@string/app_name"',
  );
  manifestFile.writeAsStringSync(manifest);

  final privateManifest = File('android/app/src/private/AndroidManifest.xml');
  privateManifest.parent.createSync(recursive: true);
  privateManifest.writeAsStringSync('''<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
</manifest>
''');
}
