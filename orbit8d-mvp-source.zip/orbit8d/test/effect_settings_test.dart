import 'package:flutter_test/flutter_test.dart';
import 'package:orbit8d/audio/filter_graph_builder.dart';
import 'package:orbit8d/models/effect_settings.dart';

void main() {
  group('EffectSettings', () {
    test('classic preset completes one orbit in eight seconds', () {
      expect(EffectSettings.classic.frequencyHz, closeTo(0.125, 0.000001));
    });

    test('changing preset preserves selected output format', () {
      final settings = EffectSettings.classic.copyWith(
        outputFormat: OutputFormat.mp3,
      );

      expect(
        settings.withPreset(EffectPreset.deep).outputFormat,
        OutputFormat.mp3,
      );
    });
  });

  group('FilterGraphBuilder', () {
    test('builds a stereo moving, widened and normalised signal', () {
      final graph = FilterGraphBuilder.build(EffectSettings.classic);

      expect(graph, contains('channel_layouts=stereo'));
      expect(graph, contains('stereowiden='));
      expect(graph, contains('apulsator='));
      expect(graph, contains('hz=0.12500'));
      expect(graph, contains('aecho='));
      expect(
        graph,
        endsWith('loudnorm=I=-16:TP=-1.5:LRA=11,aresample=48000'),
      );
    });

    test('omits room tail when reverb is zero', () {
      final graph = FilterGraphBuilder.build(
        EffectSettings.classic.copyWith(reverb: 0),
      );

      expect(graph, isNot(contains('aecho=')));
    });
  });
}
