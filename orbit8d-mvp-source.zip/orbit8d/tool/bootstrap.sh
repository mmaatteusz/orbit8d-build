#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Brak Flutter SDK w PATH." >&2
  exit 1
fi

flutter create . \
  --platforms=android,ios \
  --org=pl.orbit8d \
  --project-name=orbit8d

android_gradle="android/app/build.gradle.kts"
if [[ -f "$android_gradle" ]]; then
  sed -i.bak 's/minSdk = flutter.minSdkVersion/minSdk = 24/' "$android_gradle"
  rm -f "${android_gradle}.bak"
  dart run tool/configure_android.dart
fi

ios_podfile="ios/Podfile"
if [[ -f "$ios_podfile" ]]; then
  sed -i.bak -E "s/^#?[[:space:]]*platform :ios, '[0-9.]+'$/platform :ios, '14.0'/" "$ios_podfile"
  rm -f "${ios_podfile}.bak"
fi

flutter pub get
dart run flutter_launcher_icons
flutter analyze
flutter test

echo "Projekt gotowy. Uruchom: flutter run"
