import 'dart:math' as math;

import 'package:flutter/material.dart';

class OrbitVisualizer extends StatefulWidget {
  const OrbitVisualizer({
    required this.cycleSeconds,
    required this.movement,
    required this.active,
    this.size = 220,
    super.key,
  });

  final double cycleSeconds;
  final double movement;
  final bool active;
  final double size;

  @override
  State<OrbitVisualizer> createState() => _OrbitVisualizerState();
}

class _OrbitVisualizerState extends State<OrbitVisualizer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: _duration,
    );
    if (widget.active) _controller.repeat();
  }

  Duration get _duration => Duration(
    milliseconds: (widget.cycleSeconds * 1000)
        .round()
        .clamp(1000, 30000)
        .toInt(),
  );

  @override
  void didUpdateWidget(covariant OrbitVisualizer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.cycleSeconds != widget.cycleSeconds) {
      _controller.duration = _duration;
      if (widget.active) _controller.repeat();
    }
    if (oldWidget.active != widget.active) {
      widget.active ? _controller.repeat() : _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return SizedBox.square(
      dimension: widget.size,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Stack(
            alignment: Alignment.center,
            children: [
              CustomPaint(
                size: Size.square(widget.size),
                painter: _OrbitPainter(
                  phase: _controller.value,
                  movement: widget.movement,
                  active: widget.active,
                  primary: colors.primary,
                  secondary: colors.secondary,
                ),
              ),
              Container(
                width: widget.size * 0.34,
                height: widget.size * 0.34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: colors.surfaceContainerHigh,
                  border: Border.all(
                    color: colors.secondary.withValues(alpha: 0.32),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: colors.primary.withValues(alpha: 0.18),
                      blurRadius: 32,
                    ),
                  ],
                ),
                child: Icon(
                  Icons.headphones_rounded,
                  color: colors.onSurface,
                  size: widget.size * 0.16,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _OrbitPainter extends CustomPainter {
  const _OrbitPainter({
    required this.phase,
    required this.movement,
    required this.active,
    required this.primary,
    required this.secondary,
  });

  final double phase;
  final double movement;
  final bool active;
  final Color primary;
  final Color secondary;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.shortestSide * 0.39;
    final orbitRect = Rect.fromCenter(
      center: center,
      width: radius * 2,
      height: radius * 1.36,
    );

    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 12
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16)
      ..color = primary.withValues(alpha: active ? 0.2 : 0.1);
    canvas.drawOval(orbitRect, glow);

    final track = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..color = secondary.withValues(alpha: 0.3);
    canvas.drawOval(orbitRect, track);
    canvas.drawOval(
      Rect.fromCenter(
        center: center,
        width: radius * 1.45,
        height: radius * 1.45,
      ),
      track..color = primary.withValues(alpha: 0.16),
    );

    final angle = (phase * math.pi * 2) - (math.pi / 2);
    final x = center.dx + (math.cos(angle) * orbitRect.width / 2);
    final y = center.dy + (math.sin(angle) * orbitRect.height / 2);
    final dot = Offset(x, y);
    final dotRadius = 5 + (movement * 3);

    canvas.drawCircle(
      dot,
      dotRadius * 2.6,
      Paint()
        ..color = secondary.withValues(alpha: 0.3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9),
    );
    canvas.drawCircle(dot, dotRadius, Paint()..color = secondary);
  }

  @override
  bool shouldRepaint(covariant _OrbitPainter oldDelegate) {
    return phase != oldDelegate.phase ||
        movement != oldDelegate.movement ||
        active != oldDelegate.active ||
        primary != oldDelegate.primary ||
        secondary != oldDelegate.secondary;
  }
}
