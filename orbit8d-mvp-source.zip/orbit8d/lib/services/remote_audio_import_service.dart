import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'audio_import_service.dart';

class RemoteAudioImportService {
  static const _maximumInputBytes = 500 * 1024 * 1024;
  static const _maximumRedirects = 5;

  Future<ImportedAudio> downloadAndStage(Uri source) async {
    if (source.scheme.toLowerCase() != 'https' || source.host.isEmpty) {
      throw const UnsupportedAudioException(
        'Bezpośredni import obsługuje wyłącznie bezpieczne linki HTTPS.',
      );
    }

    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 20)
      ..idleTimeout = const Duration(seconds: 30);

    try {
      var current = source;
      for (var redirect = 0; redirect <= _maximumRedirects; redirect++) {
        final request = await client.getUrl(current);
        request.followRedirects = false;
        request.headers.set(HttpHeaders.userAgentHeader, 'Orbit8D/0.2');
        final response = await request.close();

        if (_isRedirect(response.statusCode)) {
          final location = response.headers.value(HttpHeaders.locationHeader);
          await response.drain<void>();
          if (location == null || redirect == _maximumRedirects) {
            throw const UnsupportedAudioException(
              'Serwer przekierowuje link zbyt wiele razy.',
            );
          }
          current = current.resolve(location);
          if (current.scheme.toLowerCase() != 'https') {
            throw const UnsupportedAudioException(
              'Przekierowanie prowadzi do niezabezpieczonego adresu.',
            );
          }
          continue;
        }

        if (response.statusCode < 200 || response.statusCode >= 300) {
          await response.drain<void>();
          throw UnsupportedAudioException(
            'Nie udało się pobrać pliku (HTTP ${response.statusCode}).',
          );
        }

        final contentLength = response.contentLength;
        if (contentLength > _maximumInputBytes) {
          await response.drain<void>();
          throw const UnsupportedAudioException(
            'Plik z linku przekracza limit 500 MB.',
          );
        }

        final extension = _resolveExtension(current, response);
        if (!AudioImportService.supportedExtensions.contains(extension)) {
          await response.drain<void>();
          throw const UnsupportedAudioException(
            'Link musi prowadzić bezpośrednio do pliku MP3, M4A, AAC, WAV, FLAC albo OGG.',
          );
        }

        final cache = await getTemporaryDirectory();
        final staged = File(
          p.join(
            cache.path,
            'orbit_remote_${DateTime.now().microsecondsSinceEpoch}.$extension',
          ),
        );
        final sink = staged.openWrite();
        var byteCount = 0;
        try {
          await for (final chunk in response) {
            byteCount += chunk.length;
            if (byteCount > _maximumInputBytes) {
              throw const UnsupportedAudioException(
                'Plik z linku przekracza limit 500 MB.',
              );
            }
            sink.add(chunk);
          }
          await sink.flush();
        } catch (_) {
          await sink.close();
          if (await staged.exists()) await staged.delete();
          rethrow;
        }
        await sink.close();

        if (byteCount == 0) {
          if (await staged.exists()) await staged.delete();
          throw const UnsupportedAudioException('Pobrany plik jest pusty.');
        }

        return ImportedAudio(
          displayName: _displayName(current, extension),
          stagedPath: staged.path,
          byteCount: byteCount,
        );
      }
      throw const UnsupportedAudioException('Nie udało się pobrać pliku.');
    } on UnsupportedAudioException {
      rethrow;
    } on SocketException {
      throw const UnsupportedAudioException(
        'Brak połączenia z serwerem pliku. Sprawdź internet i link.',
      );
    } on HandshakeException {
      throw const UnsupportedAudioException(
        'Serwer pliku ma nieprawidłowy certyfikat HTTPS.',
      );
    } finally {
      client.close(force: true);
    }
  }

  static bool _isRedirect(int statusCode) =>
      statusCode == HttpStatus.movedPermanently ||
      statusCode == HttpStatus.found ||
      statusCode == HttpStatus.seeOther ||
      statusCode == HttpStatus.temporaryRedirect ||
      statusCode == HttpStatus.permanentRedirect;

  static String _resolveExtension(Uri uri, HttpClientResponse response) {
    final fromPath = p.extension(uri.path).replaceFirst('.', '').toLowerCase();
    if (AudioImportService.supportedExtensions.contains(fromPath)) {
      return fromPath;
    }

    final contentType = response.headers.contentType?.mimeType.toLowerCase();
    return switch (contentType) {
      'audio/mpeg' => 'mp3',
      'audio/mp4' || 'audio/x-m4a' => 'm4a',
      'audio/aac' => 'aac',
      'audio/wav' || 'audio/x-wav' => 'wav',
      'audio/flac' || 'audio/x-flac' => 'flac',
      'audio/ogg' => 'ogg',
      _ => '',
    };
  }

  static String _displayName(Uri uri, String extension) {
    final candidate = uri.pathSegments.isEmpty ? '' : uri.pathSegments.last;
    final decoded = Uri.decodeComponent(candidate).trim();
    if (decoded.isEmpty || decoded.length > 120) return 'audio_z_linku.$extension';
    return p.extension(decoded).isEmpty ? '$decoded.$extension' : decoded;
  }
}
