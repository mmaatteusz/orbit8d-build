enum OutputFormat {
  m4a('M4A', 'AAC 256 kb/s', 'm4a'),
  mp3('MP3', 'MP3 320 kb/s', 'mp3');

  const OutputFormat(this.shortLabel, this.detailLabel, this.extension);

  final String shortLabel;
  final String detailLabel;
  final String extension;
}

enum EffectPreset { subtle, classic, deep, custom }

class EffectSettings {
  const EffectSettings({
    this.cycleSeconds = 8,
    this.movement = 0.9,
    this.width = 0.45,
    this.reverb = 0.22,
    this.outputFormat = OutputFormat.m4a,
    this.preset = EffectPreset.classic,
  });

  final double cycleSeconds;
  final double movement;
  final double width;
  final double reverb;
  final OutputFormat outputFormat;
  final EffectPreset preset;

  double get frequencyHz => 1 / cycleSeconds;

  static const subtle = EffectSettings(
    cycleSeconds: 12,
    movement: 0.62,
    width: 0.24,
    reverb: 0.08,
    preset: EffectPreset.subtle,
  );

  static const classic = EffectSettings();

  static const deep = EffectSettings(
    cycleSeconds: 5.5,
    movement: 1,
    width: 0.72,
    reverb: 0.42,
    preset: EffectPreset.deep,
  );

  EffectSettings copyWith({
    double? cycleSeconds,
    double? movement,
    double? width,
    double? reverb,
    OutputFormat? outputFormat,
    EffectPreset? preset,
  }) {
    return EffectSettings(
      cycleSeconds: cycleSeconds ?? this.cycleSeconds,
      movement: movement ?? this.movement,
      width: width ?? this.width,
      reverb: reverb ?? this.reverb,
      outputFormat: outputFormat ?? this.outputFormat,
      preset: preset ?? this.preset,
    );
  }

  EffectSettings withPreset(EffectPreset value) {
    final replacement = switch (value) {
      EffectPreset.subtle => subtle,
      EffectPreset.classic => classic,
      EffectPreset.deep => deep,
      EffectPreset.custom => this,
    };
    return replacement.copyWith(outputFormat: outputFormat);
  }
}
