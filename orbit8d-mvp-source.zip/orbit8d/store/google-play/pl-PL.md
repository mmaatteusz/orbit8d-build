# Orbit8D — karta Google Play (PL)

## Nazwa

Orbit8D

## Krótki opis

Twórz przestrzenny efekt 8D z własnych plików audio — lokalnie i offline.

## Pełny opis

Orbit8D pozwala zmienić własny plik audio w słuchawkowy efekt obracającej się
panoramy stereo. Wybierz utwór, dobierz szybkość ruchu, szerokość i pogłos,
odsłuchaj 30-sekundową próbkę, a następnie wyeksportuj gotową wersję.

Najważniejsze funkcje:

- import MP3, M4A, AAC, WAV, FLAC i OGG,
- trzy gotowe presety oraz ustawienia ręczne,
- porównanie oryginału i wersji 8D,
- eksport M4A/AAC 256 kb/s albo MP3 320 kb/s,
- zapis i udostępnianie przez system Android,
- brak konta, reklam, analityki i wysyłania muzyki na serwer.

„8D” jest popularną nazwą automatycznie poruszanej panoramy stereo, a nie
formatem ośmiokanałowym. Efekt najlepiej słychać na słuchawkach.

Aplikacja rozpoznaje linki Spotify i YouTube, ale nie pobiera ani nie modyfikuje
treści z tych serwisów. Do obróbki należy wybrać plik, do którego użytkownik ma
prawa.

## Kategoria

Muzyka i dźwięk

## Sugerowana grupa odbiorców

13+

## Dane do sekcji „Bezpieczeństwo danych”

- zbieranie danych: nie,
- udostępnianie danych: nie,
- szyfrowanie transmisji: nie dotyczy — edycja Play działa offline,
- możliwość usunięcia konta: nie dotyczy — aplikacja nie tworzy kont.

## Materiały wymagane przed publikacją

- ikona 512 × 512 px,
- grafika promocyjna 1024 × 500 px,
- co najmniej 2 zrzuty ekranu telefonu,
- publiczny adres URL niniejszej polityki prywatności,
- działający adres e-mail pomocy technicznej.
