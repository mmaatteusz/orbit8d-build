import 'package:flutter/material.dart';

import 'config/app_edition.dart';
import 'ui/editor_screen.dart';

class Orbit8DApp extends StatelessWidget {
  const Orbit8DApp({super.key});

  static const _ink = Color(0xFF070811);
  static const _violet = Color(0xFF8B5CF6);
  static const _cyan = Color(0xFF22D3EE);

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: _violet,
      brightness: Brightness.dark,
      surface: const Color(0xFF111321),
    ).copyWith(
      primary: _violet,
      secondary: _cyan,
      surfaceContainer: const Color(0xFF171A2A),
      surfaceContainerHigh: const Color(0xFF202439),
      outline: const Color(0xFF3A3E55),
    );

    return MaterialApp(
      title: AppEditionConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: scheme,
        scaffoldBackgroundColor: _ink,
        textTheme: const TextTheme(
          displaySmall: TextStyle(
            fontWeight: FontWeight.w800,
            letterSpacing: -1.2,
          ),
          headlineSmall: TextStyle(
            fontWeight: FontWeight.w700,
            letterSpacing: -0.5,
          ),
          titleLarge: TextStyle(fontWeight: FontWeight.w700),
          titleMedium: TextStyle(fontWeight: FontWeight.w600),
          bodyLarge: TextStyle(height: 1.35),
          bodyMedium: TextStyle(height: 1.35),
        ),
        cardTheme: CardThemeData(
          color: scheme.surfaceContainer.withValues(alpha: 0.82),
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: scheme.outline.withValues(alpha: 0.55)),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size(0, 54),
            padding: const EdgeInsets.symmetric(horizontal: 22),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
            textStyle: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 15,
            ),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(0, 54),
            padding: const EdgeInsets.symmetric(horizontal: 22),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
            side: BorderSide(color: scheme.outline),
            textStyle: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 15,
            ),
          ),
        ),
        sliderTheme: SliderThemeData(
          activeTrackColor: _cyan,
          inactiveTrackColor: scheme.outline.withValues(alpha: 0.5),
          thumbColor: _cyan,
          overlayColor: _cyan.withValues(alpha: 0.14),
          trackHeight: 4,
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: scheme.surfaceContainerHigh,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
      home: const EditorScreen(),
    );
  }
}
