import 'dart:async';
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new_audio/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new_audio/return_code.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../audio/filter_graph_builder.dart';
import '../models/effect_settings.dart';

class AudioProcessingException implements Exception {
  const AudioProcessingException(this.message);

  final String message;

  @override
  String toString() => message;
}

class AudioProcessingCancelledException extends AudioProcessingException {
  const AudioProcessingCancelledException() : super('Przetwarzanie anulowano.');
}

class AudioProcessor {
  Future<String> render({
    required String inputPath,
    required String displayName,
    required Duration expectedDuration,
    required EffectSettings settings,
    required bool preview,
    required void Function(double progress) onProgress,
  }) async {
    final outputPath = await _allocateOutputPath(
      displayName: displayName,
      settings: settings,
      preview: preview,
    );
    final filter = FilterGraphBuilder.build(settings);
    final targetDuration = preview && expectedDuration > const Duration(seconds: 30)
        ? const Duration(seconds: 30)
        : expectedDuration;

    final encoderArguments = switch (settings.outputFormat) {
      OutputFormat.m4a => <String>[
        '-c:a',
        'aac',
        '-b:a',
        '256k',
        '-movflags',
        '+faststart',
      ],
      OutputFormat.mp3 => <String>[
        '-c:a',
        'libmp3lame',
        '-b:a',
        '320k',
        '-id3v2_version',
        '3',
      ],
    };
    final arguments = <String>[
      '-hide_banner',
      '-y',
      '-i',
      inputPath,
      if (preview) ...['-t', '30'],
      '-vn',
      '-map_metadata',
      '0',
      '-af',
      filter,
      ...encoderArguments,
      outputPath,
    ];

    final completer = Completer<String>();

    await FFmpegKit.executeWithArgumentsAsync(
      arguments,
      (session) async {
        final returnCode = await session.getReturnCode();
        if (ReturnCode.isSuccess(returnCode)) {
          onProgress(1);
          completer.complete(outputPath);
          return;
        }

        final output = await session.getOutput();
        final file = File(outputPath);
        if (await file.exists()) await file.delete();
        if (ReturnCode.isCancel(returnCode)) {
          completer.completeError(
            const AudioProcessingCancelledException(),
          );
        } else {
          final detail = (output ?? '').trim();
          completer.completeError(
            AudioProcessingException(
              detail.isEmpty
                  ? 'Nie udało się przetworzyć tego pliku audio.'
                  : 'Silnik audio zwrócił błąd. Szczegóły zapisano w logu debugowania.',
            ),
          );
        }
      },
      null,
      (statistics) {
        if (targetDuration.inMilliseconds <= 0) return;
        final ratio = statistics.getTime() / targetDuration.inMilliseconds;
        onProgress(ratio.clamp(0, 0.99).toDouble());
      },
    );

    return completer.future;
  }

  Future<void> cancel() => FFmpegKit.cancel();

  Future<String> _allocateOutputPath({
    required String displayName,
    required EffectSettings settings,
    required bool preview,
  }) async {
    final directory = preview
        ? await getTemporaryDirectory()
        : await getApplicationDocumentsDirectory();
    final base = p
        .basenameWithoutExtension(displayName)
        .replaceAll(RegExp(r'[^a-zA-Z0-9_-]+'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .replaceAll(RegExp(r'^_|_$'), '');
    final safeBase = base.isEmpty ? 'utwor' : base;
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final marker = preview ? 'preview' : '8D';
    return p.join(
      directory.path,
      '${safeBase}_${marker}_$stamp.${settings.outputFormat.extension}',
    );
  }
}
