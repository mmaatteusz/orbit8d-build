$ErrorActionPreference = "Stop"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw "Brak Flutter SDK w PATH."
}

flutter create . --platforms=android,ios --org=pl.orbit8d --project-name=orbit8d

$androidGradle = "android/app/build.gradle.kts"
if (Test-Path $androidGradle) {
  $content = Get-Content $androidGradle -Raw
  $content = $content.Replace("minSdk = flutter.minSdkVersion", "minSdk = 24")
  [System.IO.File]::WriteAllText(
    (Resolve-Path $androidGradle).Path,
    $content,
    $Utf8NoBom
  )
  dart run tool/configure_android.dart
}

$iosPodfile = "ios/Podfile"
if (Test-Path $iosPodfile) {
  $content = Get-Content $iosPodfile -Raw
  $content = $content -replace "(?m)^#?\s*platform :ios, '[0-9.]+'$", "platform :ios, '14.0'"
  [System.IO.File]::WriteAllText(
    (Resolve-Path $iosPodfile).Path,
    $content,
    $Utf8NoBom
  )
}

flutter pub get
dart run flutter_launcher_icons
flutter analyze
flutter test

Write-Host "Projekt gotowy. Uruchom: flutter run"
