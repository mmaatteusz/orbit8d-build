enum AppEdition { play, private }

class AppEditionConfig {
  const AppEditionConfig._();

  static const _rawEdition = String.fromEnvironment(
    'ORBIT_EDITION',
    defaultValue: 'play',
  );

  static const edition = _rawEdition == 'private'
      ? AppEdition.private
      : AppEdition.play;

  static bool get isPrivate => edition == AppEdition.private;

  static String get appName => isPrivate ? 'Orbit8D Private' : 'Orbit8D';

  static String get editionLabel => isPrivate ? 'PRIVATE' : 'PLAY';

  static String get sourceDescription => isPrivate
      ? 'Pliki z telefonu lub bezpośredni link HTTPS do pliku audio.'
      : 'Pliki z telefonu, Dysku Google, OneDrive i innych dostawców plików.';
}
