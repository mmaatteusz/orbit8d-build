import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:share_plus/share_plus.dart';

import '../models/audio_project.dart';
import '../models/effect_settings.dart';
import '../services/audio_import_service.dart';
import '../services/audio_processor.dart';
import '../services/remote_audio_import_service.dart';

enum EditorStatus {
  empty,
  importing,
  ready,
  renderingPreview,
  exporting,
  done,
  error,
}

class EditorController extends ChangeNotifier {
  EditorController({
    AudioImportService? importer,
    AudioProcessor? processor,
    RemoteAudioImportService? remoteImporter,
    AudioPlayer? player,
  }) : _importer = importer ?? AudioImportService(),
       _processor = processor ?? AudioProcessor(),
       _remoteImporter = remoteImporter ?? RemoteAudioImportService(),
       player = player ?? AudioPlayer() {
    _playerStateSubscription = playerStateStream.listen((_) => _safeNotify());
  }

  final AudioImportService _importer;
  final AudioProcessor _processor;
  final RemoteAudioImportService _remoteImporter;
  final AudioPlayer player;
  late final StreamSubscription<PlayerState> _playerStateSubscription;

  AudioProject? project;
  EffectSettings settings = EffectSettings.classic;
  EditorStatus status = EditorStatus.empty;
  double progress = 0;
  String? errorMessage;
  bool playingProcessed = false;
  bool _disposed = false;

  bool get hasProject => project != null;
  bool get isBusy => status == EditorStatus.importing || isRendering;
  bool get isRendering =>
      status == EditorStatus.renderingPreview || status == EditorStatus.exporting;
  bool get canPlayProcessed =>
      project?.previewPath != null || project?.outputPath != null;
  String? get processedPath => project?.outputPath ?? project?.previewPath;

  Stream<PlayerState> get playerStateStream => player.playerStateStream;
  Stream<Duration> get positionStream => player.positionStream;
  Stream<Duration?> get durationStream => player.durationStream;

  Future<void> importAudio() async {
    if (isBusy) return;
    final previousStatus = hasProject ? EditorStatus.ready : EditorStatus.empty;
    _setState(() {
      status = EditorStatus.importing;
      errorMessage = null;
      progress = 0;
    });

    try {
      final imported = await _importer.pickAndStage();
      if (imported == null) {
        _setState(() {
          status = hasProject ? EditorStatus.ready : previousStatus;
        });
        return;
      }

      await _activateImportedAudio(imported);
    } catch (error) {
      _fail(error);
    }
  }

  Future<void> importAudioFromUrl(Uri source) async {
    if (isBusy) return;
    _setState(() {
      status = EditorStatus.importing;
      errorMessage = null;
      progress = 0;
    });

    try {
      final imported = await _remoteImporter.downloadAndStage(source);
      await _activateImportedAudio(imported);
    } catch (error) {
      _fail(error);
    }
  }

  Future<void> _activateImportedAudio(ImportedAudio imported) async {
    await player.pause();
    final duration = await player.setUrl(
          Uri.file(imported.stagedPath).toString(),
        ) ??
        Duration.zero;
    _setState(() {
      project = AudioProject(
        displayName: imported.displayName,
        inputPath: imported.stagedPath,
        duration: duration,
        inputBytes: imported.byteCount,
      );
      status = EditorStatus.ready;
      playingProcessed = false;
    });
  }

  void applyPreset(EffectPreset preset) {
    if (isRendering) return;
    final shouldReloadOriginal = playingProcessed;
    _setState(() {
      settings = settings.withPreset(preset);
      _invalidateRenderedPointers();
    });
    if (shouldReloadOriginal) unawaited(_ensureOriginalLoaded());
  }

  void setCycleSeconds(double value) => _editSettings(
    settings.copyWith(cycleSeconds: value, preset: EffectPreset.custom),
  );

  void setMovement(double value) => _editSettings(
    settings.copyWith(movement: value, preset: EffectPreset.custom),
  );

  void setWidth(double value) => _editSettings(
    settings.copyWith(width: value, preset: EffectPreset.custom),
  );

  void setReverb(double value) => _editSettings(
    settings.copyWith(reverb: value, preset: EffectPreset.custom),
  );

  void setOutputFormat(OutputFormat value) => _editSettings(
    settings.copyWith(outputFormat: value),
  );

  Future<void> renderPreview() => _render(preview: true);

  Future<void> exportFull() => _render(preview: false);

  Future<void> _render({required bool preview}) async {
    final current = project;
    if (current == null || isBusy) return;

    await player.pause();
    _setState(() {
      status = preview
          ? EditorStatus.renderingPreview
          : EditorStatus.exporting;
      errorMessage = null;
      progress = 0;
    });

    try {
      final output = await _processor.render(
        inputPath: current.inputPath,
        displayName: current.displayName,
        expectedDuration: current.duration,
        settings: settings,
        preview: preview,
        onProgress: (value) {
          if (_disposed) return;
          progress = value;
          notifyListeners();
        },
      );

      if (_disposed) return;

      project = preview
          ? current.copyWith(previewPath: output)
          : current.copyWith(outputPath: output);
      playingProcessed = true;
      await _loadCurrentVersion();
      _setState(() {
        status = preview ? EditorStatus.ready : EditorStatus.done;
        progress = 1;
      });
    } on AudioProcessingCancelledException {
      if (_disposed) return;
      _setState(() {
        status = EditorStatus.ready;
        progress = 0;
        errorMessage = null;
      });
    } catch (error) {
      _fail(error);
    }
  }

  Future<void> cancelRender() async {
    if (!isRendering) return;
    await _processor.cancel();
  }

  Future<void> toggleVersion(bool useProcessed) async {
    if (useProcessed && !canPlayProcessed) return;
    if (playingProcessed == useProcessed) return;
    await player.pause();
    playingProcessed = useProcessed;
    await _loadCurrentVersion();
    _safeNotify();
  }

  Future<void> togglePlayback() async {
    if (!hasProject || isBusy) return;
    if (player.processingState == ProcessingState.completed) {
      await player.seek(Duration.zero);
      await player.play();
      return;
    }
    if (player.playing) {
      await player.pause();
    } else {
      await player.play();
    }
  }

  Future<void> seek(Duration position) => player.seek(position);

  Future<void> shareOutput() async {
    final output = project?.outputPath;
    if (output == null) return;
    await SharePlus.instance.share(
      ShareParams(
        title: 'Orbit 8D',
        text: 'Utwór przetworzony lokalnie w Orbit 8D',
        files: [XFile(output)],
      ),
    );
  }

  Future<void> startOver() async {
    if (isBusy) return;
    await player.stop();
    _setState(() {
      project = null;
      status = EditorStatus.empty;
      progress = 0;
      errorMessage = null;
      playingProcessed = false;
      settings = EffectSettings.classic;
    });
  }

  void clearError() {
    _setState(() {
      errorMessage = null;
      status = hasProject ? EditorStatus.ready : EditorStatus.empty;
    });
  }

  void _editSettings(EffectSettings replacement) {
    if (isRendering) return;
    final shouldReloadOriginal = playingProcessed;
    _setState(() {
      settings = replacement;
      _invalidateRenderedPointers();
    });
    if (shouldReloadOriginal) unawaited(_ensureOriginalLoaded());
  }

  void _invalidateRenderedPointers() {
    final current = project;
    if (current != null) {
      project = current.copyWith(clearPreview: true, clearOutput: true);
    }
    playingProcessed = false;
    if (status == EditorStatus.done) status = EditorStatus.ready;
  }

  Future<void> _ensureOriginalLoaded() async {
    if (project == null) return;
    final path = project!.inputPath;
    await player.pause();
    await player.setUrl(Uri.file(path).toString());
  }

  Future<void> _loadCurrentVersion() async {
    final current = project;
    if (current == null) return;
    final path = playingProcessed ? processedPath : current.inputPath;
    if (path == null) return;
    await player.setUrl(Uri.file(path).toString());
  }

  void _fail(Object error) {
    _setState(() {
      status = EditorStatus.error;
      progress = 0;
      errorMessage = switch (error) {
        UnsupportedAudioException(:final message) => message,
        AudioProcessingException(:final message) => message,
        PlayerException(:final message) =>
          message ?? 'Telefon nie potrafi odtworzyć tego pliku.',
        _ => 'Wystąpił nieoczekiwany błąd. Spróbuj z innym plikiem.',
      };
    });
  }

  void _setState(VoidCallback mutation) {
    mutation();
    _safeNotify();
  }

  void _safeNotify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    unawaited(_processor.cancel());
    unawaited(_playerStateSubscription.cancel());
    unawaited(player.dispose());
    super.dispose();
  }
}
