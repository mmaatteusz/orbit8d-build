class AudioProject {
  const AudioProject({
    required this.displayName,
    required this.inputPath,
    required this.duration,
    required this.inputBytes,
    this.previewPath,
    this.outputPath,
  });

  final String displayName;
  final String inputPath;
  final Duration duration;
  final int inputBytes;
  final String? previewPath;
  final String? outputPath;

  AudioProject copyWith({
    Duration? duration,
    String? previewPath,
    String? outputPath,
    bool clearPreview = false,
    bool clearOutput = false,
  }) {
    return AudioProject(
      displayName: displayName,
      inputPath: inputPath,
      duration: duration ?? this.duration,
      inputBytes: inputBytes,
      previewPath: clearPreview ? null : previewPath ?? this.previewPath,
      outputPath: clearOutput ? null : outputPath ?? this.outputPath,
    );
  }
}
