# Orbit 8D

Mobilna aplikacja Flutter na Androida i iPhone'a, która lokalnie tworzy
popularny efekt „8D”: dźwięk płynnie krąży między kanałami, ma regulowaną
szerokość stereo i opcjonalny krótki pogłos. Projekt nie wymaga konta ani
serwera.

## Dwie edycje

- **Orbit8D Play** (`play`) — wersja do Google Play, działająca lokalnie bez
  dostępu do internetu. Importuje pliki z telefonu i systemowych dostawców,
  takich jak Dysk Google lub OneDrive.
- **Orbit8D Private** (`private`) — osobny pakiet instalowany z APK. Oprócz
  plików lokalnych może pobrać bezpośredni adres HTTPS prowadzący do pliku
  MP3/M4A/AAC/WAV/FLAC/OGG. Nie zgrywa strumieni Spotify ani YouTube i nie
  obchodzi DRM.

Obie edycje mogą być zainstalowane jednocześnie.

## Co działa

- import MP3, M4A, AAC, WAV, FLAC i OGG przez systemowy wybór pliku,
- bezpieczne kopiowanie strumieniowe — duży utwór nie jest ładowany w całości
  do pamięci RAM,
- trzy presety i ręczne sterowanie czasem obrotu, siłą ruchu, szerokością i
  pogłosem,
- 30-sekundowa próbka oraz porównanie oryginału z przetworzoną wersją,
- postęp i anulowanie renderowania,
- eksport do M4A/AAC 256 kb/s lub MP3 320 kb/s,
- zapis i udostępnienie przez natywny panel Androida/iOS,
- przetwarzanie w całości offline,
- rozpoznawanie linków Spotify, YouTube i YouTube Music z uczciwą informacją o
  ograniczeniu źródła.

## Ważne ograniczenie Spotify i YouTube

Oficjalne API Spotify przekazuje metadane i steruje odtwarzaniem, ale zabrania
pobierania nagrań oraz modyfikowania treści Spotify. YouTube również nie daje
Data API pełnego strumienia audio do dowolnego eksportu. Dlatego wersja nadająca
się do Google Play i App Store **nie pobiera ani nie zgrywa audio z linku**.

Link może zostać rozpoznany, ale do obróbki użytkownik musi wybrać posiadany i
legalnie dostępny plik. Dodanie `yt-dlp`, przechwytywania streamu Spotify albo
obchodzenia DRM uczyniłoby aplikację trudną lub niemożliwą do legalnej
publikacji, szczególnie w App Store.

## Jak działa efekt

Łańcuch audio jest budowany w
`lib/audio/filter_graph_builder.dart`:

1. konwersja do 48 kHz stereo,
2. kontrolowane poszerzenie sceny,
3. sinusoidalna modulacja lewego i prawego kanału z przesunięciem fazy 180°, 
4. opcjonalny krótki pogłos,
5. normalizacja do -16 LUFS i ograniczenie szczytów do -1,5 dBTP.

„8D” nie jest standardem ośmiokanałowym ani prawdziwym dźwiękiem obiektowym.
To marketingowa nazwa ruchomej panoramy stereo, najlepiej słyszalnej na
słuchawkach.

## Uruchomienie

Wymagania:

- aktualny stabilny Flutter (z Dartem co najmniej 3.10),
- Java 17 dla Androida,
- Android SDK,
- macOS i Xcode do kompilacji wersji iOS.

Repozytorium przechowuje kod współdzielony. Natywne katalogi generuje jedna
komenda, dzięki czemu nie są związane ze starą wersją Gradle/Xcode.

### Windows (PowerShell)

```powershell
cd orbit8d
powershell -ExecutionPolicy Bypass -File tool/bootstrap.ps1
flutter run
```

### macOS / Linux

```bash
cd orbit8d
bash tool/bootstrap.sh
flutter run
```

Skrypt tworzy `android/` i `ios/`, ustawia Android API 24 oraz iOS 14.0, pobiera
zależności i uruchamia analizę oraz testy.

## Budowanie

Android APK:

```bash
flutter build apk --flavor private --dart-define=ORBIT_EDITION=private --release
```

Android App Bundle do Google Play:

```bash
flutter build appbundle --flavor play --dart-define=ORBIT_EDITION=play --release
```

Testowe APK edycji Play:

```bash
flutter build apk --flavor play --dart-define=ORBIT_EDITION=play --release
```

iOS bez podpisu, tylko na macOS:

```bash
flutter build ios --release --no-codesign
```

Instalacja na iPhone'ach i publikacja wymagają konta Apple Developer oraz
podpisania aplikacji w Xcode. Repozytorium zawiera też workflow GitHub Actions,
który testuje projekt i wystawia gotowy artefakt APK po każdym pushu do `main`.

## Przed publikacją

1. Ustawić własny identyfikator pakietu i dane wydawcy.
2. Dodać ikonę, screenshoty i ostateczną nazwę sklepową.
3. Uzupełnić e-mail w `PRIVACY.md` i opublikować politykę pod publicznym URL.
4. Skonfigurować klucz podpisujący Android oraz App Store Connect dla iOS.
5. Zweryfikować licencje z `THIRD_PARTY_NOTICES.md`, zwłaszcza LGPL/FFmpeg.
6. Przetestować na prawdziwym Androidzie i iPhonie: import z Plików/iCloud,
   długie utwory, brak miejsca, połączenie Bluetooth i przerwanie aplikacji.

Stały klucz wysyłania do Google Play należy trzymać poza repozytorium. Przykład
konfiguracji znajduje się w `tool/key.properties.example`.

## Struktura

```text
lib/
  audio/        czysty generator łańcucha DSP
  controllers/  stan projektu, odtwarzanie i eksport
  models/       ustawienia oraz dane pliku
  services/     import, FFmpeg i klasyfikacja linków
  ui/           ekran i animowany wizualizator
test/           testy DSP, presetów i adresów źródeł
tool/           inicjalizacja natywnych projektów
```

Kod aplikacji jest dostępny na licencji MIT. Zależności zachowują własne
licencje.
