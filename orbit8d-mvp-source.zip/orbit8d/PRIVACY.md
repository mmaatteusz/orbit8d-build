# Polityka prywatności Orbit 8D

Data obowiązywania: 18 sierpnia 2026 r.

Orbit 8D przetwarza pliki audio lokalnie na urządzeniu użytkownika. Aplikacja nie
wysyła muzyki na serwer, nie wymaga konta, nie korzysta z reklam i nie zbiera
danych analitycznych ani identyfikatorów urządzenia.

Plik wybrany przez użytkownika jest kopiowany do prywatnego katalogu roboczego
aplikacji. Próbki mogą być przechowywane tymczasowo przez system. Gotowy eksport
pozostaje w prywatnym katalogu aplikacji do momentu zapisania lub udostępnienia
go przez systemowy panel udostępniania albo usunięcia danych aplikacji.

Aplikacja rozpoznaje wpisane linki Spotify, YouTube i YouTube Music wyłącznie na
podstawie ich adresu. Nie loguje użytkownika do tych usług, nie pobiera z nich
audio i nie wysyła linków na własny serwer.

Edycja Orbit8D Play nie wymaga dostępu do internetu. Systemowy wybór pliku może
udostępnić plik z usługi chmurowej wskazanej przez użytkownika; komunikacja z tą
usługą odbywa się przez system Android i aplikację jej dostawcy.

Edycja Orbit8D Private może, wyłącznie na wyraźne polecenie użytkownika, pobrać
plik audio ze wskazanego bezpośredniego adresu HTTPS. Aplikacja nie wysyła do
twórcy adresu, zawartości pliku ani informacji o wykonanej operacji.

Użytkownik odpowiada za posiadanie praw lub wymaganej zgody na przetwarzanie i
udostępnianie wybranych nagrań.

Kontakt przed publikacją należy uzupełnić o adres e-mail wydawcy.
