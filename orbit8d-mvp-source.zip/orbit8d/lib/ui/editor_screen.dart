import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';

import '../controllers/editor_controller.dart';
import '../models/effect_settings.dart';
import '../services/link_classifier.dart';
import 'widgets/orbit_visualizer.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late final EditorController _controller;

  @override
  void initState() {
    super.initState();
    _controller = EditorController()..addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _controller
      ..removeListener(_refresh)
      ..dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      body: DecoratedBox(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: const Alignment(0.65, -0.9),
            radius: 1.25,
            colors: [
              colors.primary.withValues(alpha: 0.18),
              const Color(0xFF070811),
            ],
          ),
        ),
        child: SafeArea(
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 14, 20, 44),
                sliver: SliverToBoxAdapter(
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 680),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _Header(
                            hasProject: _controller.hasProject,
                            busy: _controller.isBusy,
                            onStartOver: _controller.startOver,
                          ),
                          const SizedBox(height: 28),
                          if (_controller.hasProject)
                            _buildEditor(context)
                          else
                            _buildEmptyState(context),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Column(
      children: [
        OrbitVisualizer(
          cycleSeconds: _controller.settings.cycleSeconds,
          movement: _controller.settings.movement,
          active: _controller.status != EditorStatus.importing,
          size: 260,
        ),
        const SizedBox(height: 18),
        Text(
          'Muzyka, która\nkrąży wokół Ciebie',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.displaySmall,
        ),
        const SizedBox(height: 14),
        Text(
          'Dodaj własny plik audio, ustaw ruch stereo i wyeksportuj efekt na telefonie. Najlepiej słuchać na słuchawkach.',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
            color: colors.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 28),
        if (_controller.status == EditorStatus.importing)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: CircularProgressIndicator(),
          )
        else ...[
          FilledButton.icon(
            onPressed: _controller.importAudio,
            icon: const Icon(Icons.audio_file_rounded),
            label: const Text('Wybierz plik audio'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => _showLinkSheet(context),
            icon: const Icon(Icons.link_rounded),
            label: const Text('Wklej link Spotify / YouTube'),
          ),
        ],
        const SizedBox(height: 18),
        Text(
          'MP3 · M4A · AAC · WAV · FLAC · OGG  •  bez wysyłania do chmury',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: colors.onSurfaceVariant,
          ),
        ),
        if (_controller.errorMessage != null) ...[
          const SizedBox(height: 20),
          _ErrorCard(
            message: _controller.errorMessage!,
            onClose: _controller.clearError,
          ),
        ],
      ],
    );
  }

  Widget _buildEditor(BuildContext context) {
    final project = _controller.project!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _TrackCard(
          fileName: project.displayName,
          duration: project.duration,
          bytes: project.inputBytes,
          onReplace: _controller.isBusy ? null : _controller.importAudio,
        ),
        if (_controller.errorMessage != null) ...[
          const SizedBox(height: 14),
          _ErrorCard(
            message: _controller.errorMessage!,
            onClose: _controller.clearError,
          ),
        ],
        const SizedBox(height: 22),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 18),
            child: Column(
              children: [
                OrbitVisualizer(
                  cycleSeconds: _controller.settings.cycleSeconds,
                  movement: _controller.settings.movement,
                  active: _controller.player.playing || _controller.isRendering,
                  size: 190,
                ),
                const SizedBox(height: 4),
                _VersionSwitch(controller: _controller),
                const SizedBox(height: 12),
                _PlayerBar(controller: _controller),
              ],
            ),
          ),
        ),
        const SizedBox(height: 22),
        _SectionTitle(
          title: 'Charakter efektu',
          subtitle: 'Presety zmieniają ruch, szerokość i pogłos jednocześnie.',
        ),
        const SizedBox(height: 12),
        _PresetSelector(controller: _controller),
        const SizedBox(height: 18),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
            child: Column(
              children: [
                _EffectSlider(
                  label: 'Pełny obrót',
                  valueLabel:
                      '${_controller.settings.cycleSeconds.toStringAsFixed(1)} s',
                  icon: Icons.rotate_right_rounded,
                  value: _controller.settings.cycleSeconds,
                  min: 4,
                  max: 18,
                  onChanged: _controller.isBusy
                      ? null
                      : _controller.setCycleSeconds,
                ),
                _EffectSlider(
                  label: 'Siła ruchu',
                  valueLabel:
                      '${(_controller.settings.movement * 100).round()}%',
                  icon: Icons.spatial_audio_off_rounded,
                  value: _controller.settings.movement,
                  min: 0.3,
                  max: 1,
                  onChanged: _controller.isBusy
                      ? null
                      : _controller.setMovement,
                ),
                _EffectSlider(
                  label: 'Szerokość stereo',
                  valueLabel: '${(_controller.settings.width * 100).round()}%',
                  icon: Icons.compare_arrows_rounded,
                  value: _controller.settings.width,
                  min: 0,
                  max: 1,
                  onChanged: _controller.isBusy
                      ? null
                      : _controller.setWidth,
                ),
                _EffectSlider(
                  label: 'Pogłos',
                  valueLabel: '${(_controller.settings.reverb * 100).round()}%',
                  icon: Icons.graphic_eq_rounded,
                  value: _controller.settings.reverb,
                  min: 0,
                  max: 0.7,
                  onChanged: _controller.isBusy
                      ? null
                      : _controller.setReverb,
                  isLast: true,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 22),
        _SectionTitle(
          title: 'Eksport',
          subtitle: 'M4A jest mniejsze i najlepiej działa na obu systemach.',
        ),
        const SizedBox(height: 12),
        _OutputFormatSelector(controller: _controller),
        const SizedBox(height: 18),
        if (_controller.isRendering) ...[
          _ProcessingCard(controller: _controller),
          const SizedBox(height: 14),
        ],
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _controller.isBusy
                    ? null
                    : _controller.renderPreview,
                icon: const Icon(Icons.play_circle_outline_rounded),
                label: const Text('Próbka 30 s'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FilledButton.icon(
                onPressed: _controller.isBusy ? null : _controller.exportFull,
                icon: const Icon(Icons.auto_awesome_rounded),
                label: const Text('Przerób całość'),
              ),
            ),
          ],
        ),
        if (project.outputPath != null) ...[
          const SizedBox(height: 12),
          FilledButton.tonalIcon(
            onPressed: _controller.shareOutput,
            icon: const Icon(Icons.ios_share_rounded),
            label: const Text('Zapisz lub udostępnij gotowy plik'),
          ),
        ],
        const SizedBox(height: 18),
        Text(
          '„8D” to popularna nazwa automatycznie poruszanej panoramy stereo. To efekt słuchawkowy, nie format z ośmioma wymiarami.',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Future<void> _showLinkSheet(BuildContext context) async {
    final input = TextEditingController();
    LinkClassification? result;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final colors = Theme.of(context).colorScheme;
            return Padding(
              padding: EdgeInsets.fromLTRB(
                20,
                4,
                20,
                24 + MediaQuery.viewInsetsOf(context).bottom,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Link do utworu',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Rozpoznam źródło i pokażę, co można z nim zrobić bez obchodzenia zabezpieczeń serwisu.',
                    style: TextStyle(color: colors.onSurfaceVariant),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: input,
                    keyboardType: TextInputType.url,
                    autocorrect: false,
                    decoration: const InputDecoration(
                      labelText: 'Spotify, YouTube lub YouTube Music',
                      hintText: 'https://…',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.link_rounded),
                    ),
                    onSubmitted: (_) {
                      setSheetState(() {
                        result = LinkClassifier.classify(input.text);
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      TextButton.icon(
                        onPressed: () async {
                          final data = await Clipboard.getData('text/plain');
                          input.text = data?.text ?? '';
                        },
                        icon: const Icon(Icons.content_paste_rounded),
                        label: const Text('Wklej'),
                      ),
                      const Spacer(),
                      FilledButton(
                        onPressed: () {
                          setSheetState(() {
                            result = LinkClassifier.classify(input.text);
                          });
                        },
                        child: const Text('Sprawdź'),
                      ),
                    ],
                  ),
                  if (result != null) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: result!.isRecognized
                            ? colors.secondaryContainer.withValues(alpha: 0.45)
                            : colors.errorContainer.withValues(alpha: 0.45),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Text(
                        result!.isRecognized
                            ? 'Rozpoznano ${result!.sourceLabel}. Oficjalne API tego serwisu nie przekazuje aplikacji pełnego pliku audio do przerobienia. Wybierz posiadany plik utworu z pamięci telefonu.'
                            : 'Nie rozpoznano poprawnego linku Spotify lub YouTube.',
                      ),
                    ),
                  ],
                ],
              ),
            );
          },
        );
      },
    );
    input.dispose();
  }
}

class _Header extends StatelessWidget {
  const _Header({
    required this.hasProject,
    required this.busy,
    required this.onStartOver,
  });

  final bool hasProject;
  final bool busy;
  final Future<void> Function() onStartOver;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: LinearGradient(colors: [colors.primary, colors.secondary]),
          ),
          child: const Icon(Icons.blur_circular_rounded, color: Colors.white),
        ),
        const SizedBox(width: 12),
        const Text(
          'ORBIT 8D',
          style: TextStyle(
            fontSize: 19,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
          ),
        ),
        const Spacer(),
        if (hasProject)
          IconButton.filledTonal(
            tooltip: 'Nowy projekt',
            onPressed: busy ? null : onStartOver,
            icon: const Icon(Icons.add_rounded),
          ),
      ],
    );
  }
}

class _TrackCard extends StatelessWidget {
  const _TrackCard({
    required this.fileName,
    required this.duration,
    required this.bytes,
    required this.onReplace,
  });

  final String fileName;
  final Duration duration;
  final int bytes;
  final VoidCallback? onReplace;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: colors.primaryContainer,
                borderRadius: BorderRadius.circular(17),
              ),
              child: Icon(Icons.music_note_rounded, color: colors.onPrimaryContainer),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    fileName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${_formatDuration(duration)}  •  ${_formatBytes(bytes)}',
                    style: TextStyle(color: colors.onSurfaceVariant),
                  ),
                ],
              ),
            ),
            IconButton(
              tooltip: 'Zmień plik',
              onPressed: onReplace,
              icon: const Icon(Icons.swap_horiz_rounded),
            ),
          ],
        ),
      ),
    );
  }
}

class _VersionSwitch extends StatelessWidget {
  const _VersionSwitch({required this.controller});

  final EditorController controller;

  @override
  Widget build(BuildContext context) {
    return SegmentedButton<bool>(
      showSelectedIcon: false,
      segments: const [
        ButtonSegment(value: false, label: Text('Oryginał')),
        ButtonSegment(value: true, label: Text('Wersja 8D')),
      ],
      selected: {controller.playingProcessed},
      onSelectionChanged: controller.isBusy
          ? null
          : (selection) => controller.toggleVersion(selection.first),
    );
  }
}

class _PlayerBar extends StatelessWidget {
  const _PlayerBar({required this.controller});

  final EditorController controller;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return StreamBuilder<PlayerState>(
      stream: controller.playerStateStream,
      initialData: controller.player.playerState,
      builder: (context, stateSnapshot) {
        final state = stateSnapshot.data ?? controller.player.playerState;
        return StreamBuilder<Duration?>(
          stream: controller.durationStream,
          initialData: controller.player.duration,
          builder: (context, durationSnapshot) {
            final duration = durationSnapshot.data ?? Duration.zero;
            return StreamBuilder<Duration>(
              stream: controller.positionStream,
              initialData: controller.player.position,
              builder: (context, positionSnapshot) {
                final position = positionSnapshot.data ?? Duration.zero;
                final maximum = duration.inMilliseconds > 0
                    ? duration.inMilliseconds.toDouble()
                    : 1.0;
                final current = position.inMilliseconds
                    .clamp(0, maximum.toInt())
                    .toDouble();
                return Column(
                  children: [
                    Slider(
                      value: current,
                      min: 0,
                      max: maximum,
                      onChanged: controller.isBusy
                          ? null
                          : (value) => controller.seek(
                              Duration(milliseconds: value.round()),
                            ),
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: 48,
                          child: Text(
                            _formatDuration(position),
                            style: TextStyle(color: colors.onSurfaceVariant),
                          ),
                        ),
                        const Spacer(),
                        IconButton.filled(
                          onPressed: controller.isBusy
                              ? null
                              : controller.togglePlayback,
                          iconSize: 28,
                          icon: Icon(
                            state.playing
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                          ),
                        ),
                        const Spacer(),
                        SizedBox(
                          width: 48,
                          child: Text(
                            _formatDuration(duration),
                            textAlign: TextAlign.end,
                            style: TextStyle(color: colors.onSurfaceVariant),
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              },
            );
          },
        );
      },
    );
  }
}

class _PresetSelector extends StatelessWidget {
  const _PresetSelector({required this.controller});

  final EditorController controller;

  @override
  Widget build(BuildContext context) {
    final values = <(EffectPreset, String, IconData)>[
      (EffectPreset.subtle, 'Subtelny', Icons.air_rounded),
      (EffectPreset.classic, 'Klasyczny', Icons.blur_circular_rounded),
      (EffectPreset.deep, 'Głęboki', Icons.waves_rounded),
    ];
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: values.map((item) {
        return ChoiceChip(
          avatar: Icon(item.$3, size: 18),
          label: Text(item.$2),
          selected: controller.settings.preset == item.$1,
          onSelected: controller.isBusy
              ? null
              : (_) => controller.applyPreset(item.$1),
        );
      }).toList(),
    );
  }
}

class _EffectSlider extends StatelessWidget {
  const _EffectSlider({
    required this.label,
    required this.valueLabel,
    required this.icon,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    this.isLast = false,
  });

  final String label;
  final String valueLabel;
  final IconData icon;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double>? onChanged;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: EdgeInsets.only(bottom: isLast ? 0 : 12),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: colors.secondary),
              const SizedBox(width: 9),
              Text(label, style: Theme.of(context).textTheme.titleSmall),
              const Spacer(),
              Text(
                valueLabel,
                style: TextStyle(
                  color: colors.secondary,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _OutputFormatSelector extends StatelessWidget {
  const _OutputFormatSelector({required this.controller});

  final EditorController controller;

  @override
  Widget build(BuildContext context) {
    return SegmentedButton<OutputFormat>(
      expandedInsets: EdgeInsets.zero,
      segments: OutputFormat.values
          .map(
            (format) => ButtonSegment(
              value: format,
              label: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(format.shortLabel),
                  Text(
                    format.detailLabel,
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                ],
              ),
            ),
          )
          .toList(),
      selected: {controller.settings.outputFormat},
      onSelectionChanged: controller.isBusy
          ? null
          : (selection) => controller.setOutputFormat(selection.first),
    );
  }
}

class _ProcessingCard extends StatelessWidget {
  const _ProcessingCard({required this.controller});

  final EditorController controller;

  @override
  Widget build(BuildContext context) {
    final isPreview = controller.status == EditorStatus.renderingPreview;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Icon(Icons.tune_rounded),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    isPreview ? 'Tworzę próbkę…' : 'Przetwarzam utwór…',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                Text('${(controller.progress * 100).round()}%'),
              ],
            ),
            const SizedBox(height: 14),
            LinearProgressIndicator(value: controller.progress),
            const SizedBox(height: 10),
            TextButton.icon(
              onPressed: controller.cancelRender,
              icon: const Icon(Icons.stop_circle_outlined),
              label: const Text('Anuluj'),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 4),
        Text(subtitle, style: TextStyle(color: colors.onSurfaceVariant)),
      ],
    );
  }
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.message, required this.onClose});

  final String message;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
      decoration: BoxDecoration(
        color: colors.errorContainer.withValues(alpha: 0.55),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline_rounded, color: colors.onErrorContainer),
          const SizedBox(width: 10),
          Expanded(child: Text(message)),
          IconButton(onPressed: onClose, icon: const Icon(Icons.close_rounded)),
        ],
      ),
    );
  }
}

String _formatDuration(Duration value) {
  if (value <= Duration.zero) return '--:--';
  final minutes = value.inMinutes;
  final seconds = value.inSeconds.remainder(60).toString().padLeft(2, '0');
  return '$minutes:$seconds';
}

String _formatBytes(int value) {
  if (value >= 1024 * 1024 * 1024) {
    return '${(value / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
  if (value >= 1024 * 1024) {
    return '${(value / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
  return '${(value / 1024).toStringAsFixed(0)} KB';
}
