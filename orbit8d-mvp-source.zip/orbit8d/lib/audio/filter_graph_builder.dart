import '../models/effect_settings.dart';

/// Builds the deterministic FFmpeg audio chain used by previews and exports.
///
/// "8D audio" is a consumer label, not an eight-dimensional audio format. The
/// chain below creates a headphone-oriented moving stereo image, adds a small
/// room tail and normalises the result to avoid clipping.
class FilterGraphBuilder {
  const FilterGraphBuilder._();

  static String build(EffectSettings settings) {
    final delayMs = 8 + (settings.width * 20);
    final feedback = 0.08 + (settings.width * 0.22);
    final crossfeed = 0.05 + (settings.width * 0.22);
    final dryMix = 1 - (settings.width * 0.14);

    final filters = <String>[
      'aresample=48000',
      'aformat=sample_fmts=fltp:channel_layouts=stereo',
      'stereowiden='
          'delay=${delayMs.toStringAsFixed(2)}:'
          'feedback=${feedback.toStringAsFixed(3)}:'
          'crossfeed=${crossfeed.toStringAsFixed(3)}:'
          'drymix=${dryMix.toStringAsFixed(3)}',
      'apulsator='
          'mode=sine:'
          'amount=${settings.movement.toStringAsFixed(3)}:'
          'offset_l=0:'
          'offset_r=0.5:'
          'width=1:'
          'timing=hz:'
          'hz=${settings.frequencyHz.toStringAsFixed(5)}',
    ];

    if (settings.reverb > 0.005) {
      final firstDecay = 0.05 + (settings.reverb * 0.24);
      final secondDecay = 0.03 + (settings.reverb * 0.14);
      filters.add(
        'aecho=0.88:0.84:38|86:'
        '${firstDecay.toStringAsFixed(3)}|'
        '${secondDecay.toStringAsFixed(3)}',
      );
    }

    filters
      ..add('loudnorm=I=-16:TP=-1.5:LRA=11')
      // loudnorm may internally upsample for true-peak detection. Force a
      // predictable mobile-friendly output rate afterwards.
      ..add('aresample=48000');
    return filters.join(',');
  }
}
