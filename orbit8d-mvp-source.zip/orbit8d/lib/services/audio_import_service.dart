import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class ImportedAudio {
  const ImportedAudio({
    required this.displayName,
    required this.stagedPath,
    required this.byteCount,
  });

  final String displayName;
  final String stagedPath;
  final int byteCount;
}

class UnsupportedAudioException implements Exception {
  const UnsupportedAudioException(this.message);

  final String message;

  @override
  String toString() => message;
}

class AudioImportService {
  static const supportedExtensions = <String>{
    'mp3',
    'm4a',
    'aac',
    'wav',
    'flac',
    'ogg',
  };

  static const _maximumInputBytes = 1500 * 1024 * 1024;

  Future<ImportedAudio?> pickAndStage() async {
    final picked = await FilePicker.pickFile();
    if (picked == null) return null;

    final extension = p.extension(picked.name).replaceFirst('.', '').toLowerCase();
    if (!supportedExtensions.contains(extension)) {
      throw UnsupportedAudioException(
        'Nieobsługiwany format .$extension. Wybierz MP3, M4A, AAC, WAV, FLAC albo OGG.',
      );
    }

    final byteCount = await picked.length();
    if (byteCount > _maximumInputBytes) {
      throw const UnsupportedAudioException(
        'Plik przekracza limit 1,5 GB. Skróć go lub wybierz wersję skompresowaną.',
      );
    }

    final cache = await getTemporaryDirectory();
    final staged = File(
      p.join(
        cache.path,
        'orbit_input_${DateTime.now().microsecondsSinceEpoch}.$extension',
      ),
    );

    final sink = staged.openWrite();
    try {
      await sink.addStream(picked.readAsByteStream());
      await sink.flush();
    } catch (_) {
      await sink.close();
      if (await staged.exists()) await staged.delete();
      rethrow;
    }
    await sink.close();

    return ImportedAudio(
      displayName: picked.name,
      stagedPath: staged.path,
      byteCount: byteCount,
    );
  }
}
