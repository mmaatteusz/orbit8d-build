enum StreamingSource {
  youtube,
  youtubeMusic,
  spotify,
  directAudio,
  unsupported,
}

class LinkClassification {
  const LinkClassification(this.source, this.normalizedUri);

  final StreamingSource source;
  final Uri? normalizedUri;

  bool get isRecognized => source != StreamingSource.unsupported;

  String get sourceLabel => switch (source) {
    StreamingSource.youtube => 'YouTube',
    StreamingSource.youtubeMusic => 'YouTube Music',
    StreamingSource.spotify => 'Spotify',
    StreamingSource.directAudio => 'bezpośredni plik audio',
    StreamingSource.unsupported => 'nieznane źródło',
  };
}

class LinkClassifier {
  const LinkClassifier._();

  static LinkClassification classify(String rawValue) {
    final value = rawValue.trim();
    final uri = Uri.tryParse(value);
    if (uri == null || !uri.hasScheme || uri.host.isEmpty) {
      return const LinkClassification(StreamingSource.unsupported, null);
    }

    final host = uri.host.toLowerCase().replaceFirst(RegExp(r'^www\.'), '');
    if (host == 'music.youtube.com') {
      return LinkClassification(StreamingSource.youtubeMusic, uri);
    }
    if (host == 'youtube.com' || host == 'youtu.be' || host.endsWith('.youtube.com')) {
      return LinkClassification(StreamingSource.youtube, uri);
    }
    if (host == 'open.spotify.com' || host.endsWith('.spotify.com')) {
      return LinkClassification(StreamingSource.spotify, uri);
    }
    if (uri.scheme.toLowerCase() == 'https' && _looksLikeAudio(uri.path)) {
      return LinkClassification(StreamingSource.directAudio, uri);
    }
    return LinkClassification(StreamingSource.unsupported, uri);
  }

  static bool _looksLikeAudio(String path) => RegExp(
    r'\.(mp3|m4a|aac|wav|flac|ogg)$',
    caseSensitive: false,
  ).hasMatch(path);
}
