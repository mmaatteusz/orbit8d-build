import 'package:flutter_test/flutter_test.dart';
import 'package:orbit8d/models/effect_settings.dart';

void main() {
  test('M4A is the cross-platform default', () {
    expect(EffectSettings.classic.outputFormat, OutputFormat.m4a);
  });
}
