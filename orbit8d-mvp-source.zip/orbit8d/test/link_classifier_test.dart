import 'package:flutter_test/flutter_test.dart';
import 'package:orbit8d/services/link_classifier.dart';

void main() {
  group('LinkClassifier', () {
    test('recognises YouTube Music before generic YouTube', () {
      final result = LinkClassifier.classify(
        'https://music.youtube.com/watch?v=abc123',
      );

      expect(result.source, StreamingSource.youtubeMusic);
    });

    test('recognises short YouTube links', () {
      final result = LinkClassifier.classify('https://youtu.be/abc123');
      expect(result.source, StreamingSource.youtube);
    });

    test('recognises Spotify track links', () {
      final result = LinkClassifier.classify(
        'https://open.spotify.com/track/abc123',
      );
      expect(result.source, StreamingSource.spotify);
    });

    test('does not trust deceptive subdomains', () {
      final result = LinkClassifier.classify(
        'https://youtube.com.example.invalid/watch?v=abc123',
      );
      expect(result.source, StreamingSource.unsupported);
    });

    test('recognises direct HTTPS audio files', () {
      final result = LinkClassifier.classify(
        'https://cdn.example.com/audio/sample.MP3',
      );
      expect(result.source, StreamingSource.directAudio);
    });

    test('rejects plain text', () {
      expect(
        LinkClassifier.classify('to nie jest link').source,
        StreamingSource.unsupported,
      );
    });
  });
}
